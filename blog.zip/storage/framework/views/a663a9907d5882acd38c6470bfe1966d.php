<!DOCTYPE html>
<html>
<head>
<title><?php echo e($pageTitle); ?></title>

</head>
<body>
    <header>
        <h1>Welcome to My Blog</h1>
    </header>
    <nav>
        <!-- Navigation links go here -->
    </nav>
    <main>
        <!-- Content of the page goes here -->
    </main>
    <footer>
        <!-- Footer content goes here -->
    </footer>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\blog\resources\views/welcome.blade.php ENDPATH**/ ?>